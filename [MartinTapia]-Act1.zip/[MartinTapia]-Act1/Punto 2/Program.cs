﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /* Punto 2 - Escribir un programa en el cual se ingresen cuatro números, calcular e informar la suma de los dos primeros y el producto del
         * tercero y el cuarto. */

            int num1, num2, num3, num4, suma, suma2;
            string valor;

            Console.Write("Suma 1: Inserte el valor del 1° Numero: ");
            valor = Console.ReadLine();
            num1 = int.Parse(valor);

            Console.Write("Suma 1: Inserte el valor del 2° Numero: ");
            valor = Console.ReadLine();
            num2 = int.Parse(valor);

            suma = num1 + num2;

            Console.Write("Resultado de la primera suma: ");
            Console.WriteLine(suma);

            Console.Write("Ahora vamos con la Segunda Suma");

            Console.Write("Suma 2: Inserte el valor del 1° Numero: ");
            valor = Console.ReadLine();
            num3 = int.Parse(valor);

            Console.Write("Suma 2: Inserte el valor del 2° Numero: ");
            valor = Console.ReadLine();
            num4 = int.Parse(valor);

            suma2 = num3 + num4;

            Console.Write("Resultado de la segunda suma: ");
            Console.WriteLine(suma2);

            Console.Write("Resultado de ambas cuentas: ");
            Console.WriteLine(suma);
            Console.WriteLine(suma2);

        }
    }
}
